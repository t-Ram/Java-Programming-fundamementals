package session2;

import java.util.Scanner;

public class Calculator {
	
	
	public static void main(String arg[]) {
	//example for Scanner class
	
	System.out.println("Please enter a number to add:");
	
	Scanner sc = new Scanner(System.in); 
	
	int a = sc.nextInt();
	
	System.out.println("Please enter anothe number to add:");
	
		
	int b = sc.nextInt();
	
	System.out.println("a + b :"+ (a+b));

}
}