package session2;

import java.util.Scanner;

public class ConditionalExample {
	
	
	public static void main(String arg[]) {
		
		
		System.out.println("Enter your score: ");
		
		Scanner sc = new Scanner(System.in); 
		
		int score = sc.nextInt();
		
		if(score < 50) {
			
			System.out.println("Sorry you did not pass");
		}
		
		else if(score >=50 & score < 60 ) {
			
			System.out.println("You got pass grade");
			
		}
		else if(score >=60 & score < 80 ) {
			
			System.out.println("You got first class");
			
		}
		else if (score >=80 ) {
			
			System.out.println("You got first class with distinction");
		}
		
	}

}
