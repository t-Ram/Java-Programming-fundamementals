package session2;

public class ArithmeticExample {
	
	public static void main(String arg[]) {
		
		int i=55;
		
		int j=30;
		
		int k=10;
		
		int l=2;
		
		//addition
		
		int result= i + j;
		
		System.out.println("Adding i and j = "+result);
		
		//subtraction
		
		result= i - k;
		
		System.out.println("Subtracting k from i = "+result);
		
		//multiplication
		
		result= i * k;
		
		System.out.println("Multiplying i and k = "+result);
		
		//division
		
		result = i/l;
		
		System.out.println("Dividing i by l = "+result);
		
		//modulus operator
		result = i%k;
		System.out.println("Modulus operator  = "+result);
		
		
	}
	

}
