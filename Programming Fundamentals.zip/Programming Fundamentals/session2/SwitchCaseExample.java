package session2;

import java.util.Scanner;

public class SwitchCaseExample {
	
	public static void main(String arg[]) {
	
	System.out.println("Enter your feedback between 1 and 5 about our restaruant. To know what these numbers mean, enter any number between 1 and 5 : ");
	
	Scanner sc = new Scanner(System.in); 
	
	int feedback = sc.nextInt();
	
	// switch statement 
	switch(feedback)
	{
	   // case statements
	   // values must be of same type of expression
	   case 1:
	      // Statements
		   System.out.println("Food is not tasty and poor service");
	      break; // break is optional
	   
	   case 2 :
		   System.out.println("Food is not tasty and but service is okay");
	      // Statements
		   
	      break; // break is optional
	   
	   case 3 :
		   System.out.println("Food taste is okay and service is okay");
	      // Statements
		   break; // break is optional
		   
	   case 4 :
		   System.out.println("Food is  tasty and service is good");
	      // Statements
		   break; // break is optional
		   
	   case 5 :
		   System.out.println("Food is  awesome and service is excellent");
	      // Statements
		   break; // break is optional
	}

}
}
