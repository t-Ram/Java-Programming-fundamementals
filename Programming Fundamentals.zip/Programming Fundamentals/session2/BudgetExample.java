package session2;

import java.util.Scanner;

public class BudgetExample {
	
	public static void main(String arg[]) {
		
		System.out.println("Please enter price of rice per Kg:");
		
		Scanner sc = new Scanner(System.in); 
		
		float priceOfRice = sc.nextFloat();
		
		System.out.println("Please enter price of Coconut oil per Kg:");
		
		float priceOfOil = sc.nextFloat();
		
		System.out.println("Please enter price of wheat flour per Kg:");
		
		float priceOfWheat = sc.nextFloat();
		
		
		System.out.println("Total cost= "+ (priceOfRice+priceOfOil+priceOfWheat));
	}

}
