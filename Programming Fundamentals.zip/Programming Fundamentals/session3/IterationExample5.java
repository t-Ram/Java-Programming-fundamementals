package session3;

public class IterationExample5 {
	
public static void main(String arg[]) {
		
		
		for(int i=0; i < 10; i++ ) {
			
			if(i%2!=0) {
				continue;
			}
			System.out.println("Value of i "+ i );
			
			
		}
		
	}

}
