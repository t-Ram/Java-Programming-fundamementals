package session3;

public class IterationExample4 {
	
	public static void main(String arg[]) {
		
		String employeeNames[] = {"Ram","Kumar","Vikram","Deepa"};
		
		for(String employeeName : employeeNames ) {
			
			System.out.println("Name of the employee: "+ employeeName );
			
			
		}
		
	}

}
