package session3;

public class IterationExample1 {
	
	
	public static void main(String arg[]) {
		
		int i=10;
		
		while(i>0) {
			
			System.out.println("Value of i: "+i);
			
			i--;
		}
		
		
	}

}
