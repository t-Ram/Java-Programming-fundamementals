package session3;

public class IterationExample3 {
	
	public static void main(String arg[]) {
	
	String employeeNames[] = {"Ram","Kumar","Vikram","Deepa"};
	
	for(int i=0; i <employeeNames.length; ++i ) {
		
		System.out.println("Name of the employee: "+ employeeNames[i] );
		
		
	}
	
}

}
