package session3;

import java.util.Scanner;

public class IterationExample2 {
	
public static void main(String arg[]) {
		
	System.out.println("Enter an number less than or equal to 5");
	
	Scanner sc = new Scanner(System.in); 
	
	int i = sc.nextInt();
	
		
		do {
			
							
				
				System.out.println("value of i: "+i);
				if(i>5) {
					System.out.println("You entered a value greater than 5, please enter correct value");
					i = sc.nextInt();
				}
				else {
				i++;
				}
			
		}
		while(i <= 5 );
		
	}

}
