package session1;

public class ProfitCalculation {
	
	public static void main(String arg[]) {
		
		float buyingPrice= 20.54f;
		
		float sellingPrice= 30.50f;
		
		
		System.out.println("Buying price is "+buyingPrice);
		
		System.out.println("Selling price is "+sellingPrice);
		
	}
	
				

}
