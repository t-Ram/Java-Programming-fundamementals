package session1;

public class VariableExample {	
	
	
	public static void main(String arg[]) {
		
		int employeeNumber=3639;
		
		System.out.println("My employee number: "+employeeNumber);
		
		
	}
	

}
