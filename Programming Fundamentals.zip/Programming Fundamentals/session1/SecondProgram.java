package session1;

public class SecondProgram {
	
	
	//It is an example of single line comment
	public void main(String arg) {
		
		System.out.println("You have to call me by creating object ");
	}
	
	/**   
	 * It is an example of multiline comments.
	 * The below method has a proper signature and will be called by JVM
	 */
	
public static void main(String arg[]) {
		
		System.out.println("This is my second program ");
	}

}
