package session1;

public class FirstProgram {
	
	
	public static void main(String args[]) {
		
		System.out.println("My first Java program");
		
	}
	

}
