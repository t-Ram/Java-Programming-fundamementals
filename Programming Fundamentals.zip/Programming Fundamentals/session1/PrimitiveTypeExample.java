package session1;

public class PrimitiveTypeExample {
	
	public static void main(String arg[]) {
		
		//primitive data types
		int i=10;
		
		short s=100;
		
		byte b=99;
		
		long l=1000000000000000000L;
		
		char c='8';
		
		float f=99.56f;
		
		double d=78.9090;
		
		boolean flag=true;
		
		System.out.println("int value: "+i);
		System.out.println("short value: "+s);
		System.out.println("byte value: "+b);
		System.out.println("long value: "+l);
		System.out.println("char value: "+c);
		System.out.println("float value: "+f);
		System.out.println("double value: "+d);
		System.out.println("boolean value: "+flag);
		
				
		
	}

}
